# ASTRA — Decisões que inspiram descobertas

**01 · 5s · E se a criança fosse astronauta?**

Em ASTRA, a criança é astronauta e suas escolhas conduzem a missão.

**02 · 5s · O desafio**

Conceitos espaciais podem parecer abstratos sem decisões e consequências visíveis.

**03 · 5s · Observe. Decida. Aja.**

Na demo, explorar e acompanhar recursos dá contexto às escolhas da missão.

**04 · 5s · Uma jornada com companhia**

PIP orienta. Na visão futura, cada criança poderá personalizar seu companheiro.

**05 · 5s · A demo já está no navegador**

A demo já está no navegador, com recursos visíveis e testes técnicos.

**06 · 5s · Avalie e construa conosco**

Avaliem a demo e cocriem conosco um piloto supervisionado com educadores.
