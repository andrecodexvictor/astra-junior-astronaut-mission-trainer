# ASTRA — Mission decisions become learning

**01 · 6s · What if the learner is the astronaut?**

What if a learner stepped into the spacesuit, and every choice shaped the mission?

**02 · 6s · Curiosity has a destination**

ASTRA invites young explorers into a lunar world built around questions and action.

**03 · 6s · A mission needs a crew**

The child is the astronaut. PIP is a mentor who helps the mission move forward.

**04 · 6s · A decision has a cost**

A mission turns abstract resources into choices with visible consequences.

**05 · 6s · The question for judges**

We are exploring how play can connect space science to engineering decisions.

**06 · 6s · The learning gap**

The challenge asks how young learners can encounter space engineering without oversimplifying it or becoming overwhelmed.

**07 · 6s · Four systems. Connected decisions.**

A mission connects power, life support including water and oxygen, radiation protection, and food production.

**08 · 6s · Engagement needs purpose**

An engaging, age-appropriate environment can give exploration a purpose and invite persistence.

**09 · 6s · Trust and connection matter**

Educators need an appropriate experience, and learners need opportunities to share discoveries with people.

**10 · 6s · Our opportunity**

The opportunity is to let learners see a choice, its cost and what happens next.

**11 · 6s · Meet ASTRA**

ASTRA is an independent Babylon.js demo of a lunar mission trainer.

**12 · 6s · Observe the mission**

The learner explores a finite world and checks graphical resource indicators linked to simulation state.

**13 · 6s · Choose an action**

The mission presents tasks and resource tradeoffs, grounded in a deterministic simulation.

**14 · 6s · Respond to a warning**

When reserves run low, an authored offline buddy reminder helps draw attention to the issue.

**15 · 6s · Learn through the loop**

Our learning hypothesis is simple: observation and consequences can prompt useful reflection.

**16 · 6s · The astronaut is the learner**

The learner leads the mission; companions and mentoring support their decisions.

**17 · 6s · A buddy for the journey**

A future companion could be a dachshund, human, cat, turtle or robot, customized by the learner.

**18 · 6s · PIP is the mentor**

PIP provides a mentoring presence; the current demo uses authored, offline reminders.

**19 · 6s · Choices connect systems**

Resource accounting gives decisions a physical context; rates are teaching assumptions, not flight predictions.

**20 · 6s · A place to show discovery**

Future badges and a customizable home could make discoveries visible and invite conversation.

**21 · 6s · A demo in the browser**

A public browser demo already lets judges explore the world and inspect the mission.

**22 · 6s · Resource rules have technical tests**

Sixty-seven CPU unit tests passed, helping protect the resource rules. These tests do not measure learning.

**23 · 6s · A world built to communicate**

The demo joins a coherent world, clear resource bars and authored offline reminders. Sixteen staged visual checks passed.

**24 · 6s · Research gives us a reason to test**

A meta-analysis of 33 STEM game studies supports investigation; it did not measure ASTRA’s effectiveness.

**25 · 6s · The next validation step**

Next, complete the full-route and hardware-GPU checks, then evaluate the experience with learners and educators.

**26 · 6s · Build an institutional pilot**

We propose a supervised pilot, co-designed with educators around a real teaching context.

**27 · 6s · Measure the reasoning**

Ask learners to explain a resource tradeoff and apply the idea to a new situation.

**28 · 6s · A phased roadmap**

We would strengthen the first mission, gather pilot evidence, then explore personalization.

**29 · 6s · Evaluate the playable demo**

We invite judges to try the playable demo and evaluate how its choices work.

**30 · 6s · Partner on the next mission**

Help us co-design a supervised educator pilot and test whether mission decisions support learning.
