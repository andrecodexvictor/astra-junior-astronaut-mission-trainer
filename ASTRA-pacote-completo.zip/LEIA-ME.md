# ASTRA — artes, apresentação e demo

Este pacote reúne o conteúdo sem duplicar as mesmas artes dentro de várias pastas.

- apresentacao/: 30 slides de 6 segundos (3 minutos), PPTX editável, PDF, HTML com imagens embutidas, vídeo sem narração e caderno com 13 pranchas novas.
- codigo-fonte/docs/art/: oito pranchas anteriores e treze novas em production-vision/.
- codigo-fonte/public/assets/models/: treze modelos GLB reais do jogo.
- artes/retratos-svg/: sete retratos exportados pelo código real.
- codigo-fonte/docs/demo/fixture-captures/: sete capturas reais com estados preparados; não provam o percurso completo.
- demo-jogavel/: jogo real compilado. Descompacte e execute Iniciar.bat/Iniciar.sh com Python 3, ou iniciar.py. Abrir dist/index.html por file:// não funciona corretamente.
- codigo-fonte/: fonte completo, assets, testes, documentação e skills; não inclui node_modules.
- verificacoes/: testes e publicação.

Jogar online sem login: https://astra-mission-trainer.andrevictorandrade.chatgpt.site

A demo já tem barras gráficas, suporte à vida/energia interligados e lembretes autorais. Avatar por foto, voz/IA, broches vestíveis, aplicativo familiar e multiplayer são visões de produção. As imagens são conceitos com IA; os patches NASA são referência de uniforme, com identidade ASTRA independente e sem alegação de endosso.

67 testes em 9 arquivos e auditorias passaram. A auditoria preparada em Chromium/SwiftShader passou 16 verificações. O percurso E2E completo e GPU física continuam pendentes.
