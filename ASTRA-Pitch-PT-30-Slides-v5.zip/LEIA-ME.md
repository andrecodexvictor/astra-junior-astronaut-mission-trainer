# ASTRA — pitch completo em português

30 slides · 6 segundos por slide · 3 minutos.

- PDF: apresentação estática.
- PowerPoint: títulos e subtítulos editáveis, roteiro nas notas e transições de seis segundos.
- HTML: visualizador com iniciar/pausar, navegação e reprodução temporizada.
- Roteiro: texto para apresentação oral; não inclui áudio gravado.

As seis etapas são gancho, problema, solução, diferencial, prova e pedido. As mesmas artes aprovadas do site são reutilizadas, sem gerar novos personagens. Os textos editoriais e o roteiro estão em português; balões e créditos originais dentro das artes podem permanecer em inglês.

As ilustrações são conceitos gerados por IA e estão identificadas. Capturas da demo são cenas preparadas do protótipo. Personalização por foto, voz/IA, insígnias e multiplayer são visão futura; os testes técnicos apresentados não comprovam aprendizagem.

O HTML foi verificado em Chromium via servidor local. Caso seu navegador bloqueie arquivos locais, abra a pasta em um terminal, execute `python -m http.server 8000` e acesse http://localhost:8000/ASTRA-Pitch-PT-30-Slides-v5.html .

As fontes Liberation Sans e sua licença acompanham o pacote para facilitar a edição do PowerPoint.

Demo: https://astra-junior-mission-trainer.vercel.app/
Site institucional: https://astra-institutional.vercel.app/
Código e fontes: https://github.com/andrecodexvictor/astra-junior-astronaut-mission-trainer/tree/main/docs/presentation/v5
