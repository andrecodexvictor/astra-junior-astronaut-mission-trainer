#!/bin/sh
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then exec python3 iniciar.py; else echo "Instale Python 3 e tente novamente."; exit 1; fi
