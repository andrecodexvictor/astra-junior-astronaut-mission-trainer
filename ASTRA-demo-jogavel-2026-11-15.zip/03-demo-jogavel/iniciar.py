#!/usr/bin/env python3
import functools
import http.server
import socketserver
import threading
import webbrowser
from pathlib import Path

class Server(socketserver.TCPServer):
    allow_reuse_address = True

handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(Path(__file__).resolve().parent / "dist"))
# Prefer a stable origin so browser-local saves survive a normal restart.
server = None
for port in range(8765, 8775):
    try:
        server = Server(("127.0.0.1", port), handler)
        break
    except OSError:
        continue
if server is None:
    server = Server(("127.0.0.1", 0), handler)
with server:
    url = "http://127.0.0.1:%d/" % server.server_address[1]
    print("ASTRA: " + url, flush=True)
    print("Mantenha esta janela aberta; Ctrl+C encerra.", flush=True)
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
