@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (py -3 iniciar.py & goto :end)
where python >nul 2>nul
if not errorlevel 1 (python iniciar.py & goto :end)
echo Instale Python 3 e tente novamente.
pause
:end
