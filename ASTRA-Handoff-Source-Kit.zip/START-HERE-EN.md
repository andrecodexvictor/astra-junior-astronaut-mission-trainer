# ASTRA — Judges’ pack

Main pitch: English, 30 slides × 6 seconds = 180 seconds. Elevator pitch: Portuguese, 6 slides × 5 seconds = 30 seconds. The MP4 is a silent timing reference. Editable PowerPoint notes contain narration, source IDs and status.

Start with docs/presentation/v3/MASTER_HANDOFF_EN.md and PROMPT_FOR_NEXT_AGENT_EN.md in the source kit. Install scripts/requirements-export.txt, then run python3 scripts/build-pitch-v3.py --output-dir ./output to rebuild decks. institutional/dist/ contains the separate buildless institutional website.

Concept art and original staged demo captures are different kinds of evidence; both are labeled. Source imagery preserves original Portuguese artwork/interface text. All new institutional copy and documents are English except the requested Portuguese elevator deck. No NASA endorsement, organizer approval, submission or educational efficacy is asserted. See AI_USAGE.md, licenses, source notes and VERIFICATION.json. Pre-existing NASA-marked AI artwork and prior work require team review for an official entry.

Live institutional website: https://astra-mission-odyssey.andrevictorandrade.chatgpt.site
Playable game demo: https://astra-mission-trainer.andrevictorandrade.chatgpt.site
Game repository: https://github.com/andrecodexvictor/astra-junior-astronaut-mission-trainer

The GitHub integration refused creation of a separate institutional repository. Its complete source is supplied separately, ready for the owner-created empty astra-institutional repository.
